# 🧹 Correction du Système de Quêtes - Migration des Données

## 📋 Résumé du Problème

Après la mise en place du nouveau système de quêtes, les joueurs qui avaient des **quêtes actives du ancien système** ne pouvaient ni :

- ❌ Relancer de nouvelles quêtes
- ❌ Finir leurs quêtes actives

## 🔍 Cause Racine

Le nouveau système de quêtes attendait une **structure de données spécifique** pour les quêtes actives :

```javascript
{
  ...questData,
  startTime: new Date().toISOString(),  // ← REQUIS (manquant dans les anciennes quêtes)
  progress: 0                            // ← REQUIS (manquant dans les anciennes quêtes)
}
```

Les **anciennes quêtes** n'avaient pas ces champs, causant :

- Une impossibilité de déterminer si une quête était valide
- Des erreurs lors du calcul du temps écoulé
- Un blocage pour créer de nouvelles quêtes (la quête invalide était toujours "active")

## ✅ Solution Implémentée

### 1️⃣ Migration Automatique au Démarrage

Ajout d'une fonction `migrateQuestData()` dans `utils/database.js` qui :

- ✔️ Détecte les **anciennes quêtes invalides** (sans `startTime`)
- ✔️ Les **abandonne automatiquement**
- ✔️ Ajoute les champs manquants aux quêtes valides
- ✔️ Reconstruit la structure des quêtes si elle est corrompue

```javascript
function migrateQuestData() {
  // Pour chaque joueur :
  // 1. Vérifier si player.quests.active existe
  // 2. Vérifier que quest.startTime est présent et valide
  // 3. Si non, abandonner la quête (mettre active = null)
  // 4. Si oui, ajouter les champs manquants
}
```

**Appelée automatiquement** dans `index.js` lors du démarrage du bot.

### 2️⃣ Validation de Quête Robuste

Ajout d'une fonction `isActiveQuestValid()` dans `systems/questSystem.js` qui valide :

- Présence du champ `startTime`
- Validité du format `startTime` (date valide)
- Présence des champs de base (`title`, `description`, `duration`)

### 3️⃣ Nettoyage Automatique

Intégration de la validation dans :

- **`getNewQuest()`** : Abandon automatique d'une quête invalide avant de créer une nouvelle
- **`showActiveQuest()`** : Nettoyage si affichage d'une quête invalide
- **`completeQuest()`** : Validation avant traitement pour éviter les erreurs

## 🚀 Actions Prises

### Fichiers Modifiés

1. **`utils/database.js`** (+72 lignes)

   - Ajout de `migrateQuestData()`
   - Export de la fonction

2. **`systems/questSystem.js`** (+52 lignes)

   - Ajout de `isActiveQuestValid()`
   - Amélioration de `canTakeNewQuest()` avec validation
   - Export de `isActiveQuestValid()`

3. **`commands/quest.js`** (+60 lignes)

   - Import de `isActiveQuestValid()`
   - Validation dans `showActiveQuest()`
   - Validation dans `completeQuest()`

4. **`index.js`** (+15 lignes)
   - Appel de `migrateQuestData()` au démarrage du bot

## 📊 Résultat

**Logs du démarrage :**

```
📜 Migration des quêtes: X migrées, Y abandonnées
✅ Migration des quêtes terminée
```

### Pour Chaque Joueur Affecté :

- ✅ Les anciennes quêtes invalides sont **automatiquement supprimées**
- ✅ Les joueurs peuvent **créer de nouvelles quêtes** immédiatement
- ✅ Les joueurs peuvent **finir leurs quêtes** sans erreur
- ✅ Notification claire si une quête est supprimée

## 🔐 Sécurité

- ✅ **Sauvegarde automatique** : Backup créé avant la migration
- ✅ **Validation stricte** : Vérifications multiples des données
- ✅ **Rollback possible** : Restaurer depuis backup si besoin
- ✅ **Logs détaillés** : Tracking complet de la migration

## 📝 Notes pour l'Avenir

Pour éviter ce problème lors de futures mises à jour :

1. **Toujours migrer les données** quand on change la structure
2. **Valider les données** au point d'utilisation
3. **Créer un système de versioning** pour la structure de données
4. **Documenter les changements** de structure

## 🧪 Test

Pour vérifier manuellement :

```bash
# Vérifier les logs au démarrage du bot
npm start
# Vous verrez : "📜 Migration des quêtes: X migrées, Y abandonnées"

# Tester sur Discord :
/quete nouvelle    # Devrait fonctionner
/quete active      # Devrait afficher ou dire "Aucune quête"
/quete terminer    # Devrait fonctionner si une quête est active
```

---

**Statut** : ✅ RÉSOLU  
**Date** : 2025-01-XX  
**Impact** : Tous les joueurs affectés
