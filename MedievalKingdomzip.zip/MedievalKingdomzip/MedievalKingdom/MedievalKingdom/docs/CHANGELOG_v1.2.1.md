# 📋 Changelog v1.2.1 - Hotfix Coffre d'Enchantement

## 🐛 Bug Corrigé

### Coffre d'Enchantement Mineur ne donnait aucun enchantement

**Problème** : Les joueurs achetaient le Coffre d'Enchantement Mineur (200 💰) mais ne recevaient aucun enchantement 70% du temps.

**Cause** : Le coffre était configuré pour donner des enchantements "common" (70%) et "uncommon" (30%), mais aucun enchantement de rareté "common" n'existait dans la base de données.

**Solution** : Ajout de 5 enchantements de rareté "common" :

- 🔪 **Aiguisage** (armes) : +3 dégâts
- 🛡️ **Solidité** (armures) : +5 défense
- ❤️ **Endurance** (armures) : +15 PV max
- 🎯 **Précision** (armes) : +5 précision, +5% crit
- 🪶 **Légèreté** (armes/armures) : +3 vitesse

---

## 📊 Statistiques

### Avant

- ❌ 0 enchantements "common"
- ❌ 70% de chances de ne rien recevoir
- ❌ Coffre mineur inutilisable

### Après

- ✅ 5 enchantements "common"
- ✅ 100% de chances de recevoir un enchantement
- ✅ Tous les coffres fonctionnels

### Distribution des Enchantements

| Rareté       | Nombre | Pourcentage |
| ------------ | ------ | ----------- |
| ⚪ Common    | 5      | 25%         |
| 🟢 Uncommon  | 4      | 20%         |
| 🔵 Rare      | 6      | 30%         |
| 🟣 Epic      | 4      | 20%         |
| 🟡 Legendary | 1      | 5%          |
| **Total**    | **20** | **100%**    |

---

## 📝 Fichiers Modifiés

- `database/enchantments.json` : +5 enchantements common

---

## 🚀 Déploiement

**Type** : Hotfix - Données uniquement  
**Redémarrage requis** : ✅ Oui  
**Redéploiement commandes** : ❌ Non

```powershell
# Redémarrer le bot
node index.js
```

---

## 🎮 Test Rapide

```
/boutique-or acheter item:coffre_enchantement_mineur quantite:1
```

Vous devriez maintenant recevoir un enchantement à chaque fois !

---

**Version** : 1.2.1  
**Type** : Hotfix  
**Date** : [Date]  
**Statut** : ✅ Corrigé
