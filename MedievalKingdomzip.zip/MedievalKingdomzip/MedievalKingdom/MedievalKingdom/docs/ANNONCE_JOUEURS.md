# 🛡️ ANNONCE : Nouveau Système de Défense !

## 📢 Message à Copier-Coller sur Discord

```
@everyone

🛡️ **MISE À JOUR MAJEURE : SYSTÈME DE DÉFENSE V2.0** 🛡️

Le système de défense a été complètement revu pour rendre les combats plus stratégiques et équilibrés !

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ **NOUVEAUTÉS**

🔢 **Limite de 3 défenses par combat**
• Vous avez maintenant 3 défenses maximum par combat
• Un compteur visible vous indique combien il vous en reste
• Choisissez bien vos moments !

🛡️ **Blocage complet des attaques**
• La défense bloque maintenant **100% des dégâts** (au lieu de 50%)
• Fonctionne contre les attaques physiques ET magiques
• Aucun dégât ne passe quand vous vous défendez !

📊 **Interface améliorée**
• Nouveau compteur : `🛡️ Défenses: 3/3`
• Se met à jour en temps réel
• Toujours visible pendant le combat

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ **CHANGEMENTS**

❌ **Plus de régénération de mana**
• La défense ne régénère plus de mana
• Équilibre le système avec le blocage complet

🎯 **Plus stratégique**
• Vous ne pouvez plus spammer la défense
• Réfléchissez avant de l'utiliser
• Gardez-en pour les moments critiques !

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 **CONSEILS**

✅ **Quand utiliser la défense :**
• Quand vous êtes faible en vie
• Contre les sorts puissants
• Dans les combats longs
• Pour gagner du temps

❌ **Quand NE PAS l'utiliser :**
• Au début avec pleine vie
• Quand l'ennemi est presque mort
• Sans raison stratégique

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 **COMPARAISON**

**Avant :**
• ♾️ Défenses illimitées
• 🛡️ Réduit 50% des dégâts
• 🔮 +10% mana

**Après :**
• 🔢 3 défenses par combat
• 🛡️ Bloque 100% des dégâts
• ⚖️ Pas de bonus mana

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎮 **EXEMPLE DE COMBAT**

Tour 1 : Vous attaquez → 25 dégâts
Tour 2 : Vous défendez (2/3 restantes)
Tour 3 : Monstre attaque → 🛡️ **BLOQUÉ !** (0 dégâts)
Tour 4 : Vous lancez un sort → 40 dégâts
Tour 5 : Vous défendez (1/3 restante)
Tour 6 : Monstre lance un sort → 🛡️ **BLOQUÉ !** (0 dégâts)
Tour 7 : Vous attaquez → 28 dégâts
Tour 8 : Vous défendez (0/3 restante)
Tour 9 : Monstre attaque → 🛡️ **BLOQUÉ !** (0 dégâts)
Tour 10 : Vous essayez de défendre → ❌ **LIMITE ATTEINTE !**

**Résultat : 3 attaques bloquées = ~90 dégâts évités !**

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🚀 **TESTEZ DÈS MAINTENANT !**

Lancez `/combat monstre` pour essayer le nouveau système !

Maîtrisez la défense pour dominer les combats ! ⚔️🛡️

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

**Version 2.1.0** | Bonne chance, guerriers ! 🏰✨
```

---

## 📝 Variantes d'Annonce

### Version Courte

```
@everyone

🛡️ **NOUVEAU : Système de Défense Amélioré !**

✨ **Changements :**
• 3 défenses max par combat (compteur visible)
• Blocage COMPLET des attaques (0 dégâts !)
• Plus de régénération de mana

🎯 **Plus stratégique, plus équilibré !**

Testez avec `/combat monstre` ! ⚔️
```

### Version Détaillée avec Embed

```
@everyone

🛡️ **MISE À JOUR MAJEURE DU SYSTÈME DE COMBAT** 🛡️

**__NOUVEAUTÉS__**

**1️⃣ Limite de Défenses**
• 3 défenses maximum par combat
• Compteur visible : `🛡️ Défenses: 3/3`
• Choisissez stratégiquement !

**2️⃣ Blocage Complet**
• 100% des dégâts bloqués (au lieu de 50%)
• Fonctionne contre attaques ET sorts
• Aucun dégât ne passe !

**3️⃣ Équilibrage**
• Plus de régénération de mana
• Système plus stratégique
• Combats plus tactiques

**__CONSEILS STRATÉGIQUES__**

✅ **Utilisez la défense quand :**
→ Vous êtes faible en vie
→ L'ennemi lance un sort puissant
→ Vous avez besoin de temps

❌ **N'utilisez PAS la défense quand :**
→ Vous avez pleine vie
→ L'ennemi est presque mort
→ Vous n'avez pas de raison stratégique

**__IMPACT__**

Avant : ♾️ Illimité, 50% réduction, +10% mana
Après : 3 max, 100% blocage, pas de bonus

**__TESTEZ MAINTENANT !__**

`/combat monstre` pour essayer le nouveau système !

Que la stratégie soit avec vous ! ⚔️🛡️✨
```

---

## 🎨 Images Suggérées (à créer)

### Image 1 : Comparaison Avant/Après

```
┌─────────────────────────────────────────┐
│         AVANT          │       APRÈS    │
├────────────────────────┼────────────────┤
│  ♾️ Illimité           │  3 défenses    │
│  🛡️ -50% dégâts        │  🛡️ -100% dégâts│
│  🔮 +10% mana          │  ❌ Pas de bonus│
│  ⚠️ Spam possible      │  ✅ Stratégique │
└─────────────────────────────────────────┘
```

### Image 2 : Interface

```
┌─────────────────────────────────────────┐
│         ⚔️ COMBAT EN COURS              │
├─────────────────────────────────────────┤
│  👤 Votre Personnage                    │
│  ❤️ 85/100                              │
│  🔮 40/50                               │
│  🛡️ Défenses: 2/3  ← NOUVEAU           │
│                                         │
│  🆚                                     │
│                                         │
│  👹 Gobelin                             │
│  ❤️ 60/100                              │
│  🔮 20/30                               │
└─────────────────────────────────────────┘
```

### Image 3 : Exemple de Blocage

```
┌─────────────────────────────────────────┐
│  🛡️ ATTAQUE BLOQUÉE !                   │
│                                         │
│  Vous bloquez complètement l'attaque    │
│  du Gobelin !                           │
│                                         │
│  Dégâts subis : 0                       │
│  Défenses restantes : 1/3               │
└─────────────────────────────────────────┘
```

---

## 📊 FAQ pour les Joueurs

### Questions Fréquentes

**Q : Combien de défenses ai-je par combat ?**
R : Exactement 3 défenses par combat.

**Q : Est-ce que ça bloque tout ?**
R : Oui ! 100% des dégâts, que ce soit une attaque ou un sort.

**Q : Est-ce que je récupère du mana ?**
R : Non, cette fonctionnalité a été supprimée pour équilibrer le système.

**Q : Les monstres ont aussi une limite ?**
R : Oui, ils ont aussi 3 défenses maximum.

**Q : Que se passe-t-il si j'essaie de défendre sans défenses ?**
R : Vous verrez un message d'erreur et votre tour sera perdu.

**Q : Puis-je voir combien de défenses il me reste ?**
R : Oui ! Le compteur est visible en permanence : `🛡️ Défenses: X/3`

**Q : La défense dure combien de temps ?**
R : Elle bloque seulement la prochaine attaque, puis se désactive.

**Q : C'est mieux qu'avant ?**
R : Oui ! Plus puissant (blocage complet) mais limité (3 fois). Plus stratégique !

---

## 🎯 Réactions Attendues

### Positives ✅

- "Wow, bloquer 100% c'est puissant !"
- "Enfin un système stratégique !"
- "J'aime le compteur visible"
- "Plus équilibré qu'avant"

### Négatives ⚠️

- "Seulement 3 défenses ?"
- "Je pouvais spam avant..."
- "Plus de mana gratuit ?"

### Réponses Suggérées

**Pour "Seulement 3 défenses ?" :**

> C'est vrai, mais maintenant elles bloquent 100% des dégâts ! Une défense bien placée peut vous sauver la vie. C'est plus stratégique et équilibré.

**Pour "Je pouvais spam avant..." :**

> Le spam rendait le système déséquilibré. Maintenant, vous devez réfléchir et choisir le bon moment. C'est plus intéressant tactiquement !

**Pour "Plus de mana gratuit ?" :**

> Le mana se régénère naturellement pendant le combat. Avec le blocage complet, la défense est déjà très puissante. C'est un bon équilibre !

---

## 📅 Planning de Communication

### Jour 1 : Annonce

- Poster l'annonce principale
- Épingler le message
- Répondre aux questions

### Jour 2-3 : Suivi

- Recueillir les retours
- Répondre aux questions
- Ajuster si nécessaire

### Jour 7 : Bilan

- Faire un bilan de la mise à jour
- Partager les statistiques
- Remercier les joueurs

---

## 🎉 Message de Clôture

```
Merci à tous pour vos retours sur le nouveau système de défense ! 🛡️

Vos combats sont maintenant plus stratégiques et équilibrés.

N'hésitez pas à partager vos meilleures stratégies ! ⚔️

Bon jeu à tous ! 🏰✨
```

---

**Prêt à annoncer ! 📢**
