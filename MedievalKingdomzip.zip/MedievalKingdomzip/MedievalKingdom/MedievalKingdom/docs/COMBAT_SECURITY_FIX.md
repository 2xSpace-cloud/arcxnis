# Correction de Sécurité : Protection contre le Vol de Combat

## 🐛 Problème Identifié

Lorsque plusieurs joueurs lançaient des combats rapidement, il était possible qu'un joueur puisse interagir avec le combat d'un autre joueur, causant des conflits et des comportements inattendus.

### Scénario du Bug

1. **Joueur A** lance `/combat monstre` → Combat créé avec boutons `combat_attack_123456`
2. **Joueur B** lance `/combat monstre` → Combat créé avec boutons `combat_attack_789012`
3. Si les messages se chevauchent dans le canal, **Joueur B** pourrait cliquer sur les boutons du **Joueur A**
4. Le système récupérait le combat via `activeCombats.get(userId)` sans vérifier si le bouton appartenait au bon joueur
5. **Résultat** : Joueur B pouvait potentiellement contrôler le combat de Joueur A

## 🛡️ Solutions Implémentées

### 1. Vérification de l'ID du Bouton (Première Ligne de Défense)

**Fichier :** `events/interactionCreate.js`  
**Ligne :** 269-282

```javascript
// Pour les combats PvE, vérifier que c'est bien le joueur du bouton qui clique
if (buttonUserId !== "pvp" && buttonUserId !== userId) {
  try {
    if (!interaction.replied && !interaction.deferred) {
      return await interaction.reply({
        embeds: [
          createEmbed(
            "error",
            "❌ Ce n'est pas votre combat ! Utilisez `/combat monstre` pour démarrer votre propre combat."
          ),
        ],
        ephemeral: true,
      });
    }
  } catch (error) {
    console.error("Erreur lors de la réponse (mauvais utilisateur):", error);
  }
  return;
}
```

**Fonctionnement :**

- Extrait l'ID du joueur depuis le `customId` du bouton (`combat_attack_123456`)
- Compare cet ID avec l'ID du joueur qui clique
- Si différent (et que ce n'est pas un combat PvP), refuse l'action immédiatement
- **Exception** : Les boutons PvP (`combat_attack_pvp`) sont autorisés car deux joueurs doivent pouvoir interagir

### 2. Vérification de Propriété du Combat (Deuxième Ligne de Défense)

**Fichier :** `events/interactionCreate.js`  
**Ligne :** 320-339

```javascript
// Vérification de sécurité : s'assurer que le combat appartient bien au joueur
if (combat.player.id !== userId && combat.opponent.id !== userId) {
  console.warn(
    `⚠️ Tentative d'accès au combat d'un autre joueur par ${userId}`
  );
  try {
    if (!interaction.replied && !interaction.deferred) {
      return await interaction.reply({
        embeds: [
          createEmbed(
            "error",
            "❌ Ce combat ne vous appartient pas !\n\nUtilisez `/combat monstre` pour démarrer votre propre combat."
          ),
        ],
        ephemeral: true,
      });
    }
  } catch (error) {
    console.error("Erreur lors de la réponse (combat non autorisé):", error);
  }
  return;
}
```

**Fonctionnement :**

- Après avoir récupéré le combat, vérifie que le joueur est soit `combat.player.id` soit `combat.opponent.id`
- Si le joueur n'est ni l'un ni l'autre, refuse l'action
- **Log de sécurité** : Enregistre une alerte dans la console pour détecter les tentatives suspectes
- Fonctionne pour les combats PvE et PvP

### 3. Optimisation de la Vérification de Combat Actif

**Fichier :** `commands/combat.js`  
**Ligne :** 284-290

**Avant :**

```javascript
// Vérifier si le joueur a déjà un combat actif
for (const combat of activeCombats.values()) {
  if (combat.player.id === userId) {
    return await interaction.reply({
      embeds: [createEmbed("error", "Vous êtes déjà en combat !")],
      flags: 64,
    });
  }
}
```

**Après :**

```javascript
// Vérifier si le joueur a déjà un combat actif
if (activeCombats.has(userId)) {
  return await interaction.reply({
    embeds: [createEmbed("error", "Vous êtes déjà en combat !")],
    flags: 64,
  });
}
```

**Avantages :**

- ✅ **Plus rapide** : O(1) au lieu de O(n)
- ✅ **Plus fiable** : Vérifie directement la clé dans la Map
- ✅ **Couvre PvE et PvP** : Fonctionne pour tous les types de combat car les deux joueurs sont enregistrés dans la Map

### 4. Suppression de Code Redondant

**Fichier :** `events/interactionCreate.js`  
**Supprimé :** Vérification dupliquée aux anciennes lignes 367-380

La vérification de propriété du combat était présente deux fois dans le code. La version redondante a été supprimée car :

- La nouvelle vérification (ligne 320-339) est plus complète
- Elle inclut un log de sécurité
- Elle est placée plus tôt dans le flux d'exécution

## 🔒 Architecture de Sécurité Multi-Couches

```
┌─────────────────────────────────────────────────────────────┐
│ Joueur clique sur un bouton de combat                       │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ COUCHE 1 : Vérification de l'ID du bouton                   │
│ ✓ Le buttonUserId correspond-il au userId ?                 │
│ ✓ Exception pour les boutons PvP                            │
└────────────────────┬────────────────────────────────────────┘
                     │ ✓ Autorisé
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ Récupération du combat depuis activeCombats                 │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ COUCHE 2 : Vérification de propriété du combat              │
│ ✓ Le joueur est-il player.id ou opponent.id ?               │
│ ✓ Log de sécurité si tentative suspecte                     │
└────────────────────┬────────────────────────────────────────┘
                     │ ✓ Autorisé
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ COUCHE 3 : Vérification d'expiration                        │
│ ✓ Le combat est-il encore valide ?                          │
└────────────────────┬────────────────────────────────────────┘
                     │ ✓ Valide
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ COUCHE 4 : Vérification du tour                             │
│ ✓ Est-ce le tour du joueur ?                                │
└────────────────────┬────────────────────────────────────────┘
                     │ ✓ Son tour
                     ▼
┌─────────────────────────────────────────────────────────────┐
│ Action de combat exécutée                                    │
└─────────────────────────────────────────────────────────────┘
```

## 📊 Cas d'Usage Couverts

### ✅ Cas 1 : Combat PvE Normal

```
Joueur A lance /combat monstre
→ Boutons créés avec ID de Joueur A
→ Joueur A clique sur ses boutons
→ ✓ buttonUserId === userId
→ ✓ combat.player.id === userId
→ ✓ Action autorisée
```

### ✅ Cas 2 : Tentative de Vol de Combat PvE

```
Joueur A lance /combat monstre
→ Boutons créés avec ID de Joueur A
→ Joueur B clique sur les boutons de Joueur A
→ ❌ buttonUserId !== userId
→ ❌ Action refusée (Couche 1)
→ Message : "Ce n'est pas votre combat !"
```

### ✅ Cas 3 : Combat PvP Normal

```
Joueur A défie Joueur B
→ Boutons créés avec ID "pvp"
→ Joueur A clique
→ ✓ buttonUserId === "pvp" (exception)
→ ✓ combat.player.id === userId
→ ✓ Action autorisée
→ Joueur B clique
→ ✓ buttonUserId === "pvp" (exception)
→ ✓ combat.opponent.id === userId
→ ✓ Action autorisée
```

### ✅ Cas 4 : Combats Simultanés

```
Joueur A lance /combat monstre (combat ID: 123)
Joueur B lance /combat monstre (combat ID: 456)
→ activeCombats.set("A", combat123)
→ activeCombats.set("B", combat456)
→ Joueur A clique sur ses boutons
→ ✓ Récupère combat123
→ ✓ combat123.player.id === "A"
→ ✓ Action autorisée
→ Joueur B clique sur ses boutons
→ ✓ Récupère combat456
→ ✓ combat456.player.id === "B"
→ ✓ Action autorisée
```

### ✅ Cas 5 : Tentative de Double Combat

```
Joueur A lance /combat monstre
→ activeCombats.set("A", combat)
→ Joueur A essaie de lancer un autre /combat monstre
→ ❌ activeCombats.has("A") === true
→ ❌ Création refusée
→ Message : "Vous êtes déjà en combat !"
```

## 🔍 Logs de Sécurité

Le système enregistre maintenant les tentatives suspectes :

```javascript
console.warn(`⚠️ Tentative d'accès au combat d'un autre joueur par ${userId}`);
```

**Utilité :**

- Détection de bugs potentiels
- Identification de tentatives de triche
- Monitoring de la santé du système
- Aide au débogage

## 📁 Fichiers Modifiés

### 1. `events/interactionCreate.js`

- ✅ Ajout de la vérification de l'ID du bouton (ligne 269-282)
- ✅ Ajout de la vérification de propriété avec log (ligne 320-339)
- ✅ Suppression de la vérification redondante

### 2. `commands/combat.js`

- ✅ Optimisation de la vérification de combat actif (ligne 284-290)
- ✅ Utilisation de `activeCombats.has()` au lieu de boucle

## ✅ Tests de Validation

- ✅ Syntaxe JavaScript validée
- ✅ Protection contre le vol de combat PvE
- ✅ Fonctionnement normal des combats PvP
- ✅ Prévention des doubles combats
- ✅ Logs de sécurité fonctionnels

## 🎯 Bénéfices

1. **Sécurité Renforcée** : Impossible de contrôler le combat d'un autre joueur
2. **Meilleure Performance** : Vérification O(1) au lieu de O(n)
3. **Meilleure UX** : Messages d'erreur clairs et informatifs
4. **Monitoring** : Logs pour détecter les problèmes
5. **Code Plus Propre** : Suppression des redondances

## 🚀 Impact sur les Utilisateurs

### Messages d'Erreur Améliorés

**Avant :**

```
❌ Ce n'est pas votre combat !
```

**Après :**

```
❌ Ce n'est pas votre combat !
Utilisez `/combat monstre` pour démarrer votre propre combat.
```

Les messages guident maintenant les joueurs vers la bonne action à effectuer.

## 📝 Notes Techniques

### Structure des CustomIds

- **PvE** : `combat_attack_123456789` (ID du joueur)
- **PvP** : `combat_attack_pvp` (identifiant générique)

### Gestion de la Map activeCombats

```javascript
// PvE : 1 entrée
activeCombats.set(playerId, combat);

// PvP : 2 entrées (même objet combat)
activeCombats.set(player1Id, combat);
activeCombats.set(player2Id, combat);
```

Cette structure permet une récupération rapide en O(1) tout en maintenant la cohérence pour les combats PvP.

---

**Date de correction :** Janvier 2025  
**Version :** 2.1 - Protection contre le vol de combat  
**Priorité :** Haute (Sécurité)
