# 🛡️ Guide du Système de Défense

## 🎯 Résumé Rapide

- ✅ **3 défenses maximum** par combat
- ✅ **Blocage complet** de la prochaine attaque (0 dégâts)
- ✅ Fonctionne contre **attaques physiques ET magiques**
- ✅ **Compteur visible** dans l'interface
- ❌ Plus de régénération de mana

---

## 📖 Comment Utiliser la Défense

### Étape 1 : Lancer un Combat

```
/combat monstre
```

### Étape 2 : Vérifier vos Défenses

Regardez l'interface de combat :

```
👤 Votre Personnage
❤️ 100/100
🔮 50/50
🛡️ Défenses: 3/3  ← Vous avez 3 défenses disponibles
```

### Étape 3 : Utiliser la Défense

Cliquez sur le bouton **🛡️ Défendre**

Vous verrez :

```
🛡️ [Votre Nom] prend une position défensive !
La prochaine attaque sera bloquée complètement.
(2 défense(s) restante(s))
```

### Étape 4 : L'Attaque est Bloquée

Au tour suivant, l'ennemi attaque :

```
🛡️ [Votre Nom] bloque complètement l'attaque de [Monstre] !
```

**Résultat : 0 dégâts subis ! 🎉**

---

## 🎮 Exemple de Combat Complet

```
🎬 DÉBUT DU COMBAT

Tour 1 - Joueur
├─ Action : 🛡️ Défendre
├─ Défenses restantes : 2/3
└─ Message : "Prend une position défensive !"

Tour 2 - Monstre
├─ Action : ⚔️ Attaque (30 dégâts normalement)
├─ Résultat : 🛡️ BLOQUÉ !
└─ Dégâts subis : 0

Tour 3 - Joueur
├─ Action : ⚔️ Attaquer
├─ Dégâts infligés : 25
└─ Vie du monstre : 75/100

Tour 4 - Monstre
├─ Action : 🔮 Sort (40 dégâts normalement)
└─ Dégâts subis : 40 (pas de défense active)

Tour 5 - Joueur
├─ Action : 🛡️ Défendre
├─ Défenses restantes : 1/3
└─ Message : "Prend une position défensive !"

Tour 6 - Monstre
├─ Action : 🔮 Sort (40 dégâts normalement)
├─ Résultat : 🛡️ BLOQUÉ !
└─ Dégâts subis : 0

Tour 7 - Joueur
├─ Action : ⚔️ Attaquer
├─ Dégâts infligés : 28
└─ Vie du monstre : 47/100

Tour 8 - Monstre
├─ Action : ⚔️ Attaque (30 dégâts)
└─ Dégâts subis : 30 (pas de défense active)

Tour 9 - Joueur
├─ Action : 🛡️ Défendre
├─ Défenses restantes : 0/3
└─ Message : "Prend une position défensive !"

Tour 10 - Monstre
├─ Action : ⚔️ Attaque (30 dégâts normalement)
├─ Résultat : 🛡️ BLOQUÉ !
└─ Dégâts subis : 0

Tour 11 - Joueur
├─ Action : 🛡️ Défendre (tentative)
├─ Défenses restantes : 0/3
└─ Message : "❌ Ne peut plus se défendre ! (Limite atteinte)"

🏆 FIN DU COMBAT
```

---

## 💡 Stratégies Recommandées

### ✅ Quand Utiliser la Défense

1. **Quand vous êtes faible en vie**

   - Exemple : Vous avez 20/100 HP
   - Bloquer la prochaine attaque peut vous sauver

2. **Contre les attaques puissantes**

   - Les sorts magiques font souvent plus de dégâts
   - Bloquer un sort = économiser beaucoup de HP

3. **Dans les combats longs**

   - Si le monstre a beaucoup de vie
   - Utilisez vos défenses progressivement

4. **Pour gagner du temps**
   - Votre mana se régénère naturellement en combat
   - Bloquer une attaque = 1 tour de régénération gratuite

### ❌ Quand NE PAS Utiliser la Défense

1. **Au début du combat sans raison**

   - Vous avez pleine vie
   - Gardez vos défenses pour plus tard

2. **Quand l'ennemi est presque mort**

   - Exemple : Monstre à 10/100 HP
   - Mieux vaut attaquer pour finir le combat

3. **Après une attaque faible**

   - Si le monstre vient de faire 5 dégâts
   - Pas besoin de gaspiller une défense

4. **Quand vous avez beaucoup de vie**
   - Exemple : Vous avez 95/100 HP
   - Gardez vos défenses pour les moments critiques

---

## 📊 Comparaison des Actions

| Action          | Coût      | Effet                       | Quand l'utiliser           |
| --------------- | --------- | --------------------------- | -------------------------- |
| ⚔️ **Attaquer** | Aucun     | Dégâts physiques            | Toujours disponible        |
| 🔮 **Sort**     | 10 mana   | Dégâts magiques élevés      | Quand vous avez du mana    |
| 🛡️ **Défendre** | 1 défense | Bloque la prochaine attaque | Moments critiques (max 3x) |

---

## 🎯 Conseils Avancés

### 1. Comptez les Défenses de l'Ennemi

- Les monstres ont aussi 3 défenses
- Observez quand ils les utilisent
- Évitez d'attaquer juste après qu'ils se défendent

### 2. Alternez les Actions

```
Bon : Attaque → Défense → Sort → Attaque → Défense
Mauvais : Défense → Défense → Défense → Attaque
```

### 3. Gardez 1 Défense de Secours

- Utilisez 2 défenses pendant le combat
- Gardez la 3ème pour une urgence
- Exemple : Vous êtes à 15 HP et le monstre attaque

### 4. Combinez avec les Sorts

```
Tour 1 : Sort (coûte 10 mana)
Tour 2 : Défense (bloque l'attaque + mana se régénère)
Tour 3 : Sort (vous avez récupéré du mana)
```

---

## 🔢 Calculs Utiles

### Dégâts Bloqués par Combat

Si vous utilisez vos 3 défenses efficacement :

```
Attaque moyenne du monstre : 30 dégâts
Sort moyen du monstre : 40 dégâts

Scénario 1 : Bloquer 3 attaques
= 30 + 30 + 30 = 90 dégâts bloqués

Scénario 2 : Bloquer 2 sorts + 1 attaque
= 40 + 40 + 30 = 110 dégâts bloqués

Scénario 3 : Bloquer 3 sorts
= 40 + 40 + 40 = 120 dégâts bloqués
```

**Conclusion : Essayez de bloquer les sorts plutôt que les attaques !**

---

## ❓ Questions Fréquentes

### Q : Mes défenses se régénèrent-elles ?

**R :** Non, vous avez 3 défenses pour tout le combat. Utilisez-les sagement !

### Q : Puis-je défendre plusieurs tours d'affilée ?

**R :** Oui, mais la défense ne dure qu'un tour. Vous devez re-défendre à chaque fois.

### Q : La défense bloque-t-elle les coups critiques ?

**R :** Oui ! La défense bloque TOUTES les attaques, même les critiques.

### Q : Que se passe-t-il si j'essaie de défendre sans défenses restantes ?

**R :** Vous verrez un message d'erreur et votre tour sera perdu. Faites attention !

### Q : Les monstres ont-ils aussi une limite de défenses ?

**R :** Oui, ils ont aussi 3 défenses maximum par combat.

### Q : La défense régénère-t-elle encore du mana ?

**R :** Non, cette fonctionnalité a été supprimée pour équilibrer le système.

---

## 🎓 Exercices Pratiques

### Exercice 1 : Combat Basique

1. Lancez `/combat monstre`
2. Utilisez vos 3 défenses pendant le combat
3. Observez combien de dégâts vous avez bloqués

### Exercice 2 : Timing Parfait

1. Lancez `/combat monstre`
2. N'utilisez la défense QUE quand votre vie est < 50%
3. Essayez de gagner en utilisant seulement 2 défenses

### Exercice 3 : Blocage de Sorts

1. Lancez `/combat monstre`
2. Défendez-vous juste avant que le monstre lance un sort
3. Comptez combien de sorts vous avez bloqués

---

## 📈 Progression

### Niveau Débutant

- ✅ Comprendre le système de défense
- ✅ Utiliser les 3 défenses dans un combat
- ✅ Bloquer au moins 1 attaque

### Niveau Intermédiaire

- ✅ Utiliser la défense au bon moment
- ✅ Bloquer principalement des sorts
- ✅ Garder 1 défense de secours

### Niveau Expert

- ✅ Gagner des combats en utilisant < 3 défenses
- ✅ Anticiper les attaques ennemies
- ✅ Optimiser chaque action pour maximiser les dégâts

---

## 🏆 Défis

### Défi 1 : Économe

**Objectif :** Gagner un combat en utilisant seulement 1 défense
**Récompense :** Satisfaction personnelle 😎

### Défi 2 : Mur Impénétrable

**Objectif :** Bloquer 3 sorts consécutifs
**Récompense :** Titre de "Maître Défenseur" (non officiel)

### Défi 3 : Sans Défense

**Objectif :** Gagner un combat sans utiliser de défense
**Récompense :** Preuve de votre maîtrise du combat

---

## 🎨 Résumé Visuel

```
┌─────────────────────────────────────────┐
│         SYSTÈME DE DÉFENSE              │
├─────────────────────────────────────────┤
│                                         │
│  🛡️ DÉFENSES DISPONIBLES : 3/3         │
│                                         │
│  ┌───────────────────────────────────┐ │
│  │  Cliquer sur 🛡️ Défendre         │ │
│  └───────────────────────────────────┘ │
│              ↓                          │
│  ┌───────────────────────────────────┐ │
│  │  Position défensive activée       │ │
│  │  Défenses restantes : 2/3         │ │
│  └───────────────────────────────────┘ │
│              ↓                          │
│  ┌───────────────────────────────────┐ │
│  │  Ennemi attaque                   │ │
│  └───────────────────────────────────┘ │
│              ↓                          │
│  ┌───────────────────────────────────┐ │
│  │  🛡️ ATTAQUE BLOQUÉE !             │ │
│  │  Dégâts subis : 0                 │ │
│  └───────────────────────────────────┘ │
│                                         │
└─────────────────────────────────────────┘
```

---

## 🎉 Conclusion

Le système de défense est maintenant :

- ✅ **Stratégique** : Choisissez le bon moment
- ✅ **Puissant** : Blocage complet des attaques
- ✅ **Limité** : 3 utilisations par combat
- ✅ **Clair** : Compteur visible en permanence

**Maîtrisez la défense pour devenir un champion du combat ! ⚔️🛡️**

---

**Bon jeu ! 🏰✨**
