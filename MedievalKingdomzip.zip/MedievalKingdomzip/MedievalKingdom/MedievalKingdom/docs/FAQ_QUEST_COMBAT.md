# ❓ FAQ - Quêtes & Combat

## 🎯 Questions sur le Système de Quêtes

### Q1: Qu'est-ce qui se passe si je atteins les 10 quêtes par jour?

**R**: Tu reçois ce message:

```
❌ Limite quotidienne atteinte!

Vous avez déjà complété 10/10 quêtes aujourd'hui.
⏰ Revenez demain pour en faire d'autres!
```

Le compteur réinitialise à **minuit**.

### Q2: À quelle heure réinitialise le compteur de quêtes?

**R**: À **minuit UTC** (par rapport au serveur). C'est basé sur la date du jour avec `new Date().toDateString()`.

### Q3: Je peux faire 10 quêtes une seconde après l'autre?

**R**: **OUI!** C'est la nouvelle fonctionnalité! Pas de délai. Tu peux:

- Accepter quête 1
- Terminer quête 1
- Accepter quête 2
- Terminer quête 2
- ... jusqu'à 10 quêtes!

Tout d'affilée si tu veux.

### Q4: Les 10 quêtes sont-elles par joueur ou globales?

**R**: **Par joueur**. Chaque joueur a son propre compteur `player.quests.completedToday`.

### Q5: Si je fais 3 quêtes, me repose, puis reviens 12h plus tard, quel est mon compteur?

**R**: **0** (remis à zéro). La réinitialisation est basée sur le jour calendrier.

Exemple:

```
Lundi 10h: 3 quêtes complétées ✅ (compteur = 3)
Lundi 20h: Compteur = 3
Mardi 01h: Compteur = 0 ✅ (nouveau jour!)
```

---

## ⚔️ Questions sur les Combats

### Q1: Pourquoi le Dragon donne +60% plus de récompenses que le Gobelin?

**R**: Parce qu'il est 5x plus difficile!

Formule utilisée:

```
Bonus = 1 + (difficultyLevel - 1) × 0.15

Gobelin (niveau 1): 1 + (1-1) × 0.15 = 1.00 (×1)
Loup (niveau 2): 1 + (2-1) × 0.15 = 1.15 (×1.15)
Squelette (niveau 3): 1 + (3-1) × 0.15 = 1.30 (×1.30)
Orc (niveau 4): 1 + (4-1) × 0.15 = 1.45 (×1.45)
Dragon (niveau 5): 1 + (5-1) × 0.15 = 1.60 (×1.60)
```

### Q2: Si je combats un Dragon à faible niveau, ca va comment?

**R**: Tu recevras:

- Les récompenses NORMALES du Dragon (50-100 or, 75-150 XP)
- Pas d'ajustement pour le "trop difficile"
- C'est au joueur de gérer sa progression!

### Q3: Les récompenses du monstre sont aléatoires?

**R**: **OUI!** Chaque combat:

```javascript
Math.floor(Math.random() * (expRange[1] - expRange[0] + 1)) + expRange[0];
```

Exemple Dragon:

- Min: 75 XP
- Max: 150 XP
- Chaque combat: Random entre les deux

### Q4: Où est calculé le niveau de difficulté du monstre?

**R**: Dans `systems/gameData.js`:

```javascript
dragon: {
  name: "Jeune Dragon",
  difficultyLevel: 5,  // ← Ici!
  loot: { gold: [50, 100], experience: [75, 150], ... }
}
```

### Q5: Comment ajouter un nouveau monstre avec ses récompenses?

**R**: Ajoute ceci à `systems/gameData.js` dans `const monsters = {...}`:

```javascript
phoenix: {
  name: "Phénix",
  emoji: "🔥",
  baseHealth: 250,
  baseMana: 100,
  stats: { attack: 25, defense: 20, magicAttack: 25, magicDefense: 18, speed: 14 },
  abilities: ["Souffle de feu intense", "Régénération", "Apothéose"],
  loot: {
    gold: [75, 150],
    experience: [100, 200],
    items: ["baton_legendaire", "potion_soin"],
  },
  levelRange: [12, 20],
  difficultyLevel: 5,  // ← Même que Dragon = Boss
}
```

Puis ajoute à la fin du fichier dans `module.exports`:

```javascript
module.exports = {
  classes,
  factions,
  monsters, // Phénix sera inclus automatiquement
  events,
};
```

---

## 💡 Cas d'Usage Pratiques

### Cas 1: Progression Rapide

```
Objectif: Gagner XP vite et progresser

Stratégie:
1. Faire 10 quêtes → Gagne 250+ XP
2. Combattre Dragon × 3 → Gagne 360+ XP
3. Total: 600+ XP en une session!

Ancien système: Au mieux 50 XP/quête (limite 30 min)
```

### Cas 2: Farming de Gold

```
Objectif: Accumuler de l'or pour un item

Stratégie:
1. Faire 10 quêtes (chacune 10-30 or) = 200 or
2. Combattre Orc × 5 (12-25 or chacun) = 85 or
3. Total: 285 or en une session!

💡 Conseil: Combattre Dragon si besoin urgent (80-160 or/combat)
```

### Cas 3: Farming de Items

```
Objectif: Obtenir 10 potions de soin

Stratégie:
1. Gobelin et Loup dropent "potion_soin"
2. Combats vs Gobelin/Loup
3. Même les petits monstres aident!
4. 10 combats = ~3-4 potions (si chance)

💡 Il faut plusieurs essais (25% drop chance environ)
```

### Cas 4: Session Casual (30 min)

```
Temps: 30 minutes
Limite quêtes: 10 (mais temps limité)

Temps par quête: 3 min (faire + terminer)
Quêtes possibles: 30 min / 3 min = ~10 ✅

Résultat: Peut compléter la limite en 30 min!
```

### Cas 5: Session Hardcore (2 heures)

```
Temps: 2 heures = 120 min
Quêtes: 10 (durée: ~30 min total)
Combats: Reste 90 min

Combats par minute: 1 toutes les 2 min
Total combats: ~45 combats possibles!

Récompenses: 1800+ or, 2000+ XP! 🤑
```

---

## ⚙️ Configuration & Personnalisation

### Changer la Limite de Quêtes

Fichier: `systems/questSystem.js` ligne 290

```javascript
// De:
const DAILY_QUEST_LIMIT = 10;

// À (exemple: 20 quêtes/jour):
const DAILY_QUEST_LIMIT = 20;
```

### Changer le Bonus de Difficulté

Fichier: `systems/combatSystem.js` ligne 646

```javascript
// De: +15% par niveau
const difficultyBonus = 1 + (difficultyLevel - 1) * 0.15;

// À: +20% par niveau
const difficultyBonus = 1 + (difficultyLevel - 1) * 0.2;

// Résultat pour Dragon:
// Avant: 1.60x
// Après: 1.80x
```

### Ajouter un Bonus de Temps (Plus de quêtes les week-ends?)

```javascript
// Dans questSystem.js canTakeNewQuest()
const today = new Date();
const isWeekend = today.getDay() === 0 || today.getDay() === 6;
const DAILY_QUEST_LIMIT = isWeekend ? 15 : 10;
```

---

## 🐛 Troubleshooting

### Problème: Le compteur ne réinitialise pas

**Cause possible**: Vérifier le fuseau horaire du serveur
**Solution**:

```javascript
// Dans questSystem.js
const today = now.toDateString(); // Basé sur la zone de serveur
// Assurez-vous que c'est la même zone partout
```

### Problème: Les récompenses semblent trop hautes/basses

**Cause possible**: Vérifier le `difficultyLevel` du monstre
**Solution**:

```javascript
// Dans systems/gameData.js
// Vérifier que difficultyLevel est entre 1 et 5
dragon: {
  difficultyLevel: 5, // ✅ Correct
  // difficultyLevel: 10, // ❌ Trop haut!
}
```

### Problème: Les joueurs atteignent 10/10 trop rapides

**Cause possible**: Les quêtes sont trop faciles/courtes
**Solution**:

- Augmenter la durée des quêtes dans `database/quests.json`
- Ou réduire la limite quotidienne dans `questSystem.js`

---

## 📊 Statistiques Référence

### Quêtes

- **Limite par jour**: 10
- **Réinitialisation**: Minuit UTC
- **Délai entre quêtes**: 0 (aucun!)
- **Récompense moyenne/quête**: 25 XP, 10 or

### Combat vs Monstres

| Monstre   | Or Range | XP Range | Temps Estimé | Or/Min |
| --------- | -------- | -------- | ------------ | ------ |
| Gobelin   | 3-8      | 8-15     | 1 min        | 5.5    |
| Loup      | 5-12     | 12-20    | 1.5 min      | 5.7    |
| Squelette | 8-15     | 15-25    | 2 min        | 5.5    |
| Orc       | 12-25    | 20-35    | 2.5 min      | 6.8    |
| Dragon    | 80-160   | 120-240  | 5 min        | 20     |

💡 **Dragon = Meilleur taux or/min pour les endgame!**

---

## 🔔 À Retenir

1. ✅ **10 quêtes max/jour** (plus de 30 min cooldown!)
2. ✅ **Récompenses basées sur difficulté** (Dragon >> Gobelin)
3. ✅ **Compteur réinitialise à minuit**
4. ✅ **Affichage clair de la difficulté** (🟢🟡🔴)
5. ✅ **Système extensible** (facile d'ajouter des monstres)

---

**Fin de la FAQ** ✨
