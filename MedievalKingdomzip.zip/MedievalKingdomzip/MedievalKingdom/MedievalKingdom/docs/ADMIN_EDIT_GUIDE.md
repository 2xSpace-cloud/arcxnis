# Guide de la commande `/admin edit`

## 📋 Description

La commande `/admin edit` permet aux administrateurs de modifier facilement les statistiques, ressources, classe et faction d'un joueur via un panneau interactif avec des boutons et menus déroulants.

## 🎯 Utilisation

```
/admin edit joueur:@utilisateur
```

## 🖥️ Interface interactive

### Menu principal

Après avoir exécuté la commande, un panneau s'affiche avec 4 boutons de catégories :

1. **📊 Statistiques** - Modifier les stats du personnage
2. **💰 Ressources** - Modifier les ressources du joueur
3. **⚔️ Classe** - Changer la classe du personnage
4. **🏰 Faction** - Changer la faction du personnage

### 📊 Statistiques modifiables

- **Niveau** - Le niveau du personnage
- **Points de vie (PV)** - Les PV actuels
- **PV Maximum** - Les PV maximum
- **Mana** - Le mana actuel
- **Mana Maximum** - Le mana maximum
- **Attaque** - La statistique d'attaque
- **Défense** - La statistique de défense

### 💰 Ressources modifiables

- **Or** - La monnaie principale
- **Gemmes** - La monnaie premium
- **Expérience** - Les points d'expérience
- **Réputation** - La réputation du joueur

### ⚔️ Classes disponibles

- **Chevalier** ⚔️ - Noble guerrier du royaume
- **Mage** 🔮 - Érudit des arts arcaniques
- **Voleur** 🗡️ - Maître de la discrétion
- **Barde** 🎵 - Artiste et aventurier

**Note :** Changer la classe ajuste automatiquement les statistiques de base selon la nouvelle classe.

### 🏰 Factions disponibles

- **Ordre Royal** 👑 - Serviteurs de la couronne
- **Guilde des Ombres** 🌙 - Organisation secrète
- **Cercle Druidique** 🌿 - Gardiens de la nature
- **Académie Arcanique** 🏛️ - Institution magique
- **Aucune faction** ❌ - Retirer le joueur de sa faction

## 🔄 Navigation

- **◀️ Retour** - Retourne au menu principal
- **❌ Fermer** - Ferme le panneau d'édition

## 📝 Fonctionnalités

### Modification de valeurs

1. Sélectionnez une catégorie (Stats ou Ressources)
2. Choisissez l'élément à modifier dans le menu déroulant
3. Un formulaire modal s'ouvre
4. Entrez la nouvelle valeur
5. Validez

### Changement de classe

1. Cliquez sur "Classe"
2. Sélectionnez la nouvelle classe dans le menu déroulant
3. Les statistiques de base sont automatiquement ajustées

### Changement de faction

1. Cliquez sur "Faction"
2. Sélectionnez la nouvelle faction dans le menu déroulant
3. La faction est immédiatement changée

## 📊 Logging automatique

Toutes les modifications importantes sont automatiquement enregistrées dans les logs d'audit :

- ✅ Changements d'or
- ✅ Changements d'expérience
- ✅ Changements de niveau
- ✅ Changements de classe
- ✅ Changements de faction

## ⚠️ Permissions requises

- Permissions d'administrateur Discord
- Seuls les administrateurs peuvent utiliser cette commande

## 🎨 Avantages par rapport à `/admin set`

1. **Interface visuelle** - Plus intuitive avec des boutons et menus
2. **Aperçu en temps réel** - Voir les valeurs actuelles avant modification
3. **Navigation facile** - Retour au menu principal à tout moment
4. **Modification de classe/faction** - Nouvelles fonctionnalités
5. **Ajustement automatique** - Les stats de base s'ajustent lors du changement de classe
6. **Meilleure UX** - Pas besoin de retaper la commande pour chaque modification

## 📌 Exemples d'utilisation

### Modifier les statistiques d'un joueur

```
/admin edit joueur:@Jean
→ Cliquer sur "Statistiques"
→ Sélectionner "Niveau"
→ Entrer "10"
→ Valider
```

### Donner de l'or à un joueur

```
/admin edit joueur:@Marie
→ Cliquer sur "Ressources"
→ Sélectionner "Or"
→ Entrer "1000"
→ Valider
```

### Changer la classe d'un joueur

```
/admin edit joueur:@Pierre
→ Cliquer sur "Classe"
→ Sélectionner "Mage"
→ Les stats sont automatiquement ajustées
```

### Assigner une faction

```
/admin edit joueur:@Sophie
→ Cliquer sur "Faction"
→ Sélectionner "Ordre Royal"
→ La faction est assignée
```

## 🔧 Maintenance

Le système utilise :

- **Boutons Discord** pour la navigation
- **Menus déroulants** pour les sélections
- **Modals** pour la saisie de valeurs
- **Embeds** pour l'affichage des informations

Tous les composants sont gérés dans le fichier `events/adminEditInteraction.js`.
