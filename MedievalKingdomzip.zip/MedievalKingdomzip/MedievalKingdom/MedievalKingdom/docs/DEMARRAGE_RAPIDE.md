# 🚀 Démarrage Rapide - Système d'Or

## ⚡ Installation en 3 étapes

### 1️⃣ Démarrer le bot

```powershell
node index.js
```

### 2️⃣ Enregistrer les commandes (si nécessaire)

```powershell
node deploy-commands.js
```

> ⚠️ Modifiez `config.js` et ajoutez votre `guildId` pour un enregistrement instantané sur votre serveur

### 3️⃣ Tester les commandes

```
/boutique-or voir
/forge info item:epee_longue
/familier liste
```

---

## 🎮 Commandes principales

### 🏪 Boutique d'Or

```
/boutique-or voir                              → Voir toutes les catégories
/boutique-or voir categorie:consumables        → Voir les consommables
/boutique-or acheter item:potion_soin          → Acheter 1 potion
/boutique-or acheter item:potion_soin quantite:5  → Acheter 5 potions
```

### ⚒️ Forge

```
/forge ameliorer item:epee_longue              → Améliorer une épée
/forge info item:epee_longue                   → Voir les stats
/forge enchantements                           → Voir vos enchantements
/forge enchanter item:epee_longue enchantement:feu  → Enchanter
```

### 🐾 Familiers

```
/familier liste                                → Voir vos familiers
/familier equiper familier:chat_noir           → Équiper un familier
/familier desequiper                           → Déséquiper
/familier info familier:dragon_bebe            → Voir les infos
```

---

## 📝 Scénario de test complet (5 min)

### Étape 1 : Vérifier votre or

```
/personnage
```

> Vous devriez avoir 100 or de base

### Étape 2 : Acheter des potions

```
/boutique-or acheter item:potion_soin quantite:2
```

> Coût : 50 or (25 × 2)

### Étape 3 : Acheter une arme

```
/boutique-or acheter item:epee_courte
```

> Coût : 100 or (reste -50 or, vous devez faire des quêtes !)

### Étape 4 : Faire une quête pour gagner de l'or

```
/quete nouvelle
```

> Attendez le temps requis

```
/quete terminer
```

> Vous gagnez de l'or et de l'XP !

### Étape 5 : Acheter et améliorer

```
/boutique-or acheter item:epee_longue
/forge ameliorer item:epee_longue
/forge info item:epee_longue
```

### Étape 6 : Acheter un familier

```
/boutique-or acheter item:chat_noir
/familier equiper familier:chat_noir
/familier liste
```

### Étape 7 : Acheter un coffre d'enchantement

```
/boutique-or acheter item:coffre_enchantement
/forge enchantements
```

### Étape 8 : Enchanter votre arme

```
/forge enchanter item:epee_longue enchantement:<id_obtenu>
/forge info item:epee_longue
```

---

## 💰 Gagner de l'or rapidement

### Méthode 1 : Quêtes

```
/quete nouvelle
```

> Attendez 15-30 minutes

```
/quete terminer
```

> Récompense : 15-50 or

### Méthode 2 : Combats

```
/combat pve
```

> Choisissez un monstre et battez-le
> Récompense : 3-100 or selon le monstre

### Méthode 3 : Bonus de familier

```
/familier equiper familier:renard
```

> +15% d'or sur toutes les récompenses !

---

## 🎯 Objectifs pour débuter

### Objectif 1 : Premier équipement (200 or)

- ✅ Acheter une épée longue
- ✅ L'améliorer au niveau +1

### Objectif 2 : Premier familier (150 or)

- ✅ Acheter un chat noir
- ✅ L'équiper

### Objectif 3 : Premier enchantement (500 or)

- ✅ Acheter un coffre d'enchantement
- ✅ Enchanter une arme

### Objectif 4 : Build complet (2000+ or)

- ✅ Arme +5 avec enchantement
- ✅ Armure +3
- ✅ Familier Rare équipé
- ✅ Stock de potions

---

## 🐛 Problèmes courants

### "Vous devez créer un personnage"

```
/personnage creer
```

### "Vous n'avez pas assez d'or"

- Faites des quêtes : `/quete nouvelle`
- Faites des combats : `/combat pve`
- Équipez un familier avec bonus d'or

### "Item introuvable"

- Vérifiez l'ID exact avec `/boutique-or voir categorie:<catégorie>`
- Copiez-collez l'ID depuis la boutique

### "Vous ne possédez pas cet item"

- Achetez l'item d'abord à la boutique
- Vérifiez votre inventaire : `/inventaire`

### Les commandes n'apparaissent pas

1. Attendez 1-2 minutes
2. Redémarrez Discord
3. Lancez `node deploy-commands.js`

---

## 📚 Documentation complète

- **`GUIDE_SYSTEME_OR.md`** - Guide détaillé avec toutes les infos
- **`RESUME_SYSTEME_OR.md`** - Résumé technique
- **`TEST_SYSTEME_OR.md`** - Plan de tests complet

---

## 🎉 C'est parti !

Vous êtes prêt à utiliser le système d'or !

**Commencez par :**

1. `/boutique-or voir` - Découvrir la boutique
2. `/quete nouvelle` - Gagner de l'or
3. `/boutique-or acheter` - Faire vos premiers achats

**Bon jeu ! 💰✨**
