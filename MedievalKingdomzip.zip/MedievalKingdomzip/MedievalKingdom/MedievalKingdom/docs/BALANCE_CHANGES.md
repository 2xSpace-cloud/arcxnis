# 📊 Changements d'Équilibre du Jeu

## 🎯 Objectif

Rééquilibrer les classes et factions pour que le gameplay soit équitable pour tous les joueurs.

---

## ⚔️ Modifications des Classes

### Chevalier (Inchangé)

- **Attaque:** 18 (Inchangé)
- **Défense:** 15 (Inchangé)
- **Santé:** 120 (Inchangé)

### Voleur (AMÉLIORÉ)

- **Attaque:** 14 → **16** (+2) ✅
- **Défense:** 8 → **10** (+2) ✅
- Reste inchangé: Santé 90, Mana 50, Vitesse 18

### Mage (AMÉLIORÉ)

- **Santé:** 80 → **90** (+10) ✅
- **Défense:** 6 → **10** (+4) ✅
- **Attaque Magique:** 20 → **22** (+2) ✅
- Reste inchangé: Mana 100, Vitesse 10

### Barde (AMÉLIORÉ)

- **Attaque:** 10 → **12** (+2) ✅
- **Défense:** 10 → **12** (+2) ✅
- **Attaque Magique:** 12 → **14** (+2) ✅
- **Mana:** 70 → **80** (+10) ✅

---

## 👑 Modifications des Factions

### Système de Coûts d'Adhésion

Chaque faction a maintenant un **coût d'adhésion** basé sur sa puissance:

#### 👑 Ordre Royal

- **Niveau de Puissance:** 8/10
- **Coût d'Adhésion:**
  - 🪙 **5000 or**
  - 📊 **+50 réputation**
- **Limitation:** Chevaliers uniquement

#### 🌙 Guilde des Ombres

- **Niveau de Puissance:** 9/10 (LA PLUS FORTE)
- **Coût d'Adhésion:**
  - 🪙 **8000 or** (LE PLUS ÉLEVÉ)
  - 📊 **-50 réputation** (coût en réputation)
- **Limitation:** Voleurs uniquement

#### 🌿 Cercle Druidique

- **Niveau de Puissance:** 6/10
- **Coût d'Adhésion:**
  - 🪙 **2000 or** (LE PLUS BAS)
  - 📊 **+30 réputation**
- **Limitation:** Mages et Bardes

#### 🏛️ Académie Arcanique

- **Niveau de Puissance:** 7/10
- **Coût d'Adhésion:**
  - 🪙 **6000 or**
  - 📊 **+40 réputation**
- **Limitation:** Mages uniquement

---

## 📋 Résumé des Équilibres

### Avant les changements:

| Classe    | Attaque | Défense | Santé | État           |
| --------- | ------- | ------- | ----- | -------------- |
| Chevalier | 18      | 15      | 120   | OP ⚠️          |
| Voleur    | 14      | 8       | 90    | Faible 😢      |
| Mage      | 6       | 6       | 80    | Très Faible 😢 |
| Barde     | 10      | 10      | 100   | Faible 😢      |

### Après les changements:

| Classe    | Attaque | Défense | Santé | État             |
| --------- | ------- | ------- | ----- | ---------------- |
| Chevalier | 18      | 15      | 120   | Forte 💪         |
| Voleur    | 16      | 10      | 90    | Équilibré ✅     |
| Mage      | 6       | 10      | 90    | Mieux protégé ✅ |
| Barde     | 12      | 12      | 100   | Équilibré ✅     |

---

## 💰 Impact du Système de Coûts

- **Ordre Royal:** Coût standard, faction équilibrée
- **Guilde des Ombres:** **COÛT ÉLEVÉ** (8000 or) pour compenser sa puissance offensif (+15% critique)
- **Cercle Druidique:** Coût bas (2000 or) pour les nouveaux joueurs
- **Académie Arcanique:** Coût moyen (6000 or)

Les coûts reflètent le **niveau de puissance** de chaque faction:

- Plus forte la faction → Plus cher à rejoindre

---

## 🔧 Changements Techniques

### Fichiers Modifiés:

1. **systems/gameData.js**

   - Ajout du champ `powerLevel` pour chaque faction
   - Ajout du champ `joinCost` pour chaque faction
   - Augmentation des stats des classes

2. **commands/faction.js**
   - Vérification des coûts avant adhésion
   - Déduction de l'or et réputation
   - Affichage des coûts dans les messages
   - Affichage des coûts dans les infos de faction

---

## ✅ Avantages de ces Changements

1. **Équilibre PvP:** Les classes sont maintenant plus équilibrées
2. **Progression Économique:** Les factions fortes coûtent plus cher
3. **Gestion des Ressources:** Les joueurs doivent choisir stratégiquement
4. **Récompense de l'Effort:** Joindre une faction forte demande du travail
5. **Jeu Plus Juste:** Moins d'avantage déséquilibré

---

## 🎮 Gameplay Impact

### Pour les Chevaliers:

- Toujours puissants en combat direct
- Mais coût élevé pour Ordre Royal (5000 or)

### Pour les Voleurs:

- Défense améliorée (8→10)
- Attaque améliorée (14→16)
- Accès à la meilleure faction mais au coût le plus élevé (8000 or)

### Pour les Mages:

- Bien plus robustes (80→90 santé, défense 6→10)
- Attaque magique améliorée (20→22)
- Choix entre Académie Arcanique (fort) ou Cercle Druidique (économique)

### Pour les Bardes:

- Équilibre amélioré
- Plus de mana (70→80)
- Tous les stats augmentés
- Accès au Cercle Druidique (faction économique)

---

## 📝 Notes

- Les coûts ne sont applicables que lors de la **première adhésion**
- Les joueurs peuvent quitter et rejoindre d'autres factions (en payant à nouveau)
- Les coûts en réputation negative s'ajoutent à la réputation actuelle
- L'audit log continue à tracer tous les changements
