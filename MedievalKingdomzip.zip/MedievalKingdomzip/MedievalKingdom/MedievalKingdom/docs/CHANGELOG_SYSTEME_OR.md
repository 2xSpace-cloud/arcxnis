# 📝 Changelog - Système d'Or et d'Amélioration

## 🎉 Nouvelles fonctionnalités

### 🏪 Boutique d'Or (`/boutique-or`)

- **Nouvelle commande** pour acheter des items avec de l'or
- **4 catégories** d'items disponibles :
  - 🧪 Consommables (potions, buffs)
  - ⚔️ Équipements (armes, armures, boucliers)
  - 🐾 Familiers (12 compagnons différents)
  - 📦 Coffres d'Enchantement (4 niveaux de rareté)

### ⚒️ Système de Forge (`/forge`)

- **Amélioration d'items** : Niveaux illimités avec coût exponentiel
  - Chaque niveau ajoute +10% des stats de base
  - Formule de coût : `100 × (1.5 ^ niveau actuel)`
  - Aucun risque d'échec
- **Système d'enchantements** :
  - 15 enchantements différents
  - 1 enchantement par item
  - Possibilité de remplacer un enchantement
  - Enchantements obtenus via coffres aléatoires

### 🐾 Système de Familiers (`/familier`)

- **12 familiers** de différentes raretés (Common à Legendary)
- **3 types de bonus** :
  - Bonus de stats (attaque, défense, vitesse, etc.)
  - Bonus économiques (or, XP, loot)
  - Capacités de combat (attaques, soins, boucliers)
- Un seul familier équipé à la fois

---

## 📁 Fichiers créés

### Commandes

- `commands/goldshop.js` - Boutique d'or
- `commands/forge.js` - Amélioration et enchantement
- `commands/familiar.js` - Gestion des familiers

### Base de données

- `database/goldShop.json` - Items de la boutique d'or
- `database/enchantments.json` - Liste des enchantements
- `database/familiars.json` - Liste des familiers

### Documentation

- `GUIDE_SYSTEME_OR.md` - Guide complet du système
- `CHANGELOG_SYSTEME_OR.md` - Ce fichier

---

## 🔧 Modifications de la structure des données joueur

### Nouveaux champs ajoutés

```javascript
{
  // Existant
  "gold": 100,
  "inventory": {},

  // Nouveaux champs
  "familiars": [],              // IDs des familiers possédés
  "equippedFamiliar": null,     // ID du familier équipé
  "enchantments": [],           // IDs des enchantements possédés
  "itemUpgrades": {             // Niveaux d'amélioration des items
    "item_id": {
      "level": 0
    }
  },
  "itemEnchantments": {         // Enchantements appliqués aux items
    "item_id": "enchantment_id"
  }
}
```

---

## 📊 Statistiques du système

### Items disponibles

- **8 consommables** (25-120 or)
- **14 équipements** (80-800 or)
- **12 familiers** (150-3000 or)
- **4 coffres d'enchantement** (200-3000 or)
- **15 enchantements** (5 raretés)

### Raretés

- ⚪ Common (5 items)
- 🟢 Uncommon (8 items)
- 🔵 Rare (7 items)
- 🟣 Epic (5 items)
- 🟡 Legendary (2 items)

---

## 🎮 Commandes disponibles

### `/boutique-or`

- `voir` - Affiche les catégories
- `voir categorie:<catégorie>` - Affiche une catégorie
- `acheter item:<id> [quantite:<nombre>]` - Achète un item

### `/forge`

- `ameliorer item:<id>` - Améliore un équipement
- `enchanter item:<id> enchantement:<id>` - Applique un enchantement
- `info item:<id>` - Voir les infos d'un équipement
- `enchantements` - Voir vos enchantements disponibles

### `/familier`

- `liste` - Voir tous vos familiers
- `equiper familier:<id>` - Équiper un familier
- `desequiper` - Déséquiper votre familier
- `info familier:<id>` - Voir les infos d'un familier

---

## 💡 Équilibrage

### Coûts d'amélioration

| Niveau | Coût (or) | Coût cumulé |
| ------ | --------- | ----------- |
| +1     | 100       | 100         |
| +2     | 150       | 250         |
| +3     | 225       | 475         |
| +5     | 506       | 1,381       |
| +10    | 3,834     | 11,302      |
| +15    | 29,047    | 85,661      |
| +20    | 220,079   | 649,318     |

### Prix des familiers par rareté

- Common : 150-200 or
- Uncommon : 350-400 or
- Rare : 600-700 or
- Epic : 1,200-1,500 or
- Legendary : 2,500-3,000 or

### Prix des coffres d'enchantement

- Mineur (Common/Uncommon) : 200 or
- Standard (Uncommon/Rare) : 500 or
- Supérieur (Rare/Epic) : 1,200 or
- Légendaire (Epic/Legendary) : 3,000 or

---

## 🔄 Compatibilité

### Systèmes existants

✅ Compatible avec le système de combat
✅ Compatible avec le système de quêtes
✅ Compatible avec le système d'inventaire
✅ Compatible avec le système de gemmes
✅ Compatible avec les factions

### Intégrations futures possibles

- Appliquer les bonus de familiers en combat
- Appliquer les effets d'enchantements en combat
- Ajouter des quêtes spécifiques pour obtenir des familiers rares
- Système de craft pour créer des enchantements
- Marché entre joueurs pour échanger items/familiers

---

## 🐛 Tests recommandés

### Tests de base

- [ ] Acheter un consommable
- [ ] Acheter un équipement
- [ ] Acheter un familier
- [ ] Acheter un coffre d'enchantement
- [ ] Améliorer un item au niveau +1
- [ ] Améliorer un item au niveau +5
- [ ] Appliquer un enchantement
- [ ] Remplacer un enchantement
- [ ] Équiper un familier
- [ ] Déséquiper un familier

### Tests de limites

- [ ] Acheter sans assez d'or
- [ ] Améliorer un consommable (devrait échouer)
- [ ] Enchanter un consommable (devrait échouer)
- [ ] Appliquer un enchantement incompatible
- [ ] Acheter un familier déjà possédé
- [ ] Équiper un familier non possédé

### Tests d'affichage

- [ ] Voir la boutique complète
- [ ] Voir chaque catégorie
- [ ] Voir les infos d'un item amélioré
- [ ] Voir les infos d'un item enchanté
- [ ] Voir la liste des familiers
- [ ] Voir la liste des enchantements

---

## 📈 Métriques à suivre

### Économie

- Or moyen par joueur
- Or dépensé par catégorie
- Items les plus achetés
- Niveau d'amélioration moyen

### Engagement

- Nombre de familiers possédés par joueur
- Familiers les plus populaires
- Enchantements les plus utilisés
- Taux d'utilisation de la forge

---

## 🚀 Prochaines étapes

### Court terme

1. Tester toutes les commandes
2. Équilibrer les prix si nécessaire
3. Ajouter des messages d'aide contextuels
4. Créer des tutoriels in-game

### Moyen terme

1. Intégrer les bonus de familiers dans le système de combat
2. Intégrer les effets d'enchantements dans le système de combat
3. Ajouter des animations/effets visuels
4. Créer un système de succès/achievements

### Long terme

1. Système de craft d'enchantements
2. Marché entre joueurs
3. Familiers évolutifs (niveaux, évolutions)
4. Enchantements combinables
5. Système de sets d'équipements

---

## 📞 Support

Pour toute question ou bug, consultez :

- `GUIDE_SYSTEME_OR.md` - Guide complet
- `README.md` - Documentation générale
- Discord du serveur - Support communautaire

---

**Version :** 1.0.0  
**Date :** 2025  
**Auteur :** MedievalKingdom Team
