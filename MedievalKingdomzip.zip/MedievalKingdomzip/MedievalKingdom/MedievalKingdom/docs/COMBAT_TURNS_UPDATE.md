# Mise à Jour du Système de Tours de Combat

## 📋 Résumé des Changements

Le système de comptage des tours a été modifié pour que **chaque joueur dispose de 10 tours individuels** au lieu d'un total de 10 tours partagés.

## 🔄 Ancien Système vs Nouveau Système

### ❌ Ancien Système

- **Total de 10 tours partagés** entre le joueur et l'adversaire
- En PvE : 5 tours pour le joueur + 5 tours pour le monstre = 10 tours au total
- En PvP : 5 tours par joueur = 10 tours au total
- Le compteur `combat.turn` s'incrémentait à chaque changement de tour

### ✅ Nouveau Système

- **10 tours par joueur** (comptés individuellement)
- En PvE : 10 tours pour le joueur + 10 tours pour le monstre = 20 tours au total
- En PvP : 10 tours par joueur = 20 tours au total
- Deux compteurs séparés : `combat.playerTurns` et `combat.opponentTurns`

## 🛠️ Modifications Techniques

### 1. Structure de Combat (`combatSystem.js`)

**Nouveaux champs ajoutés :**

```javascript
{
  playerTurns: 0,      // Compteur de tours du joueur uniquement
  opponentTurns: 0,    // Compteur de tours de l'adversaire
  maxTurns: 10,        // Limite de tours PAR joueur (non partagée)
}
```

### 2. Fonction `switchTurn()` (`combatSystem.js`)

**Avant :**

```javascript
function switchTurn(combat) {
  combat.currentTurn =
    combat.currentTurn === combat.player.id
      ? combat.opponent.id
      : combat.player.id;
  combat.turn++;
}
```

**Après :**

```javascript
function switchTurn(combat) {
  // Incrémenter le compteur du joueur qui vient de jouer
  if (combat.currentTurn === combat.player.id) {
    combat.playerTurns++;
  } else {
    combat.opponentTurns++;
  }

  // Changer le tour
  combat.currentTurn =
    combat.currentTurn === combat.player.id
      ? combat.opponent.id
      : combat.player.id;
  combat.turn++;
}
```

### 3. Vérification de Limite de Tours (`combatSystem.js`)

**Avant :**

```javascript
if (combat.turn > combat.maxTurns) {
  // Fin du combat
}
```

**Après :**

```javascript
if (combat.playerTurns >= combat.maxTurns) {
  // Fin du combat
}
```

### 4. Affichage dans l'Interface (`combat.js`)

**Avant :**

```javascript
const turnsRemaining = combat.maxTurns - combat.turn + 1;
value: `Tours restants: ${turnsRemaining}/${combat.maxTurns}`;
```

**Après :**

```javascript
const playerTurnsRemaining = combat.maxTurns - combat.playerTurns;
value: `Tours de ${player.name}: ${combat.playerTurns}/${combat.maxTurns}`;
```

## 📊 Exemples de Scénarios

### Scénario PvE (Combat contre un Monstre)

**Tour 1 :** Joueur attaque → `playerTurns = 1`  
**Tour 2 :** Monstre attaque → `opponentTurns = 1`  
**Tour 3 :** Joueur attaque → `playerTurns = 2`  
**Tour 4 :** Monstre attaque → `opponentTurns = 2`  
...  
**Tour 19 :** Joueur attaque → `playerTurns = 10`  
**Tour 20 :** Monstre attaque → `opponentTurns = 10`

→ **Fin du combat après le tour 19** (quand `playerTurns >= 10`)

### Scénario PvP (Duel entre Joueurs)

**Tour 1 :** Joueur A attaque → `playerTurns = 1` (pour le joueur A)  
**Tour 2 :** Joueur B attaque → `opponentTurns = 1` (pour le joueur B)  
...  
**Tour 19 :** Joueur A attaque → `playerTurns = 10`

→ **Fin du combat après 10 tours du joueur principal**

## 🎯 Avantages du Nouveau Système

1. **Plus équitable** : Chaque joueur a exactement 10 actions
2. **Plus clair** : L'affichage montre explicitement les tours du joueur
3. **Plus de stratégie** : Les combats durent plus longtemps, permettant plus de tactiques
4. **Meilleur équilibre** : Les combats PvE ne se terminent plus prématurément

## ⚠️ Avertissement de Fin de Combat

L'avertissement visuel (⚠️) apparaît maintenant quand il reste **3 tours ou moins au joueur** :

```javascript
const playerTurnsRemaining = combat.maxTurns - combat.playerTurns;
const turnWarning = playerTurnsRemaining <= 3 ? " ⚠️" : "";
```

## 🔍 Fichiers Modifiés

1. **`systems/combatSystem.js`**

   - Ajout de `playerTurns` et `opponentTurns` dans `initiateCombat()`
   - Modification de `switchTurn()` pour incrémenter les bons compteurs
   - Modification des vérifications de limite de tours (2 endroits)

2. **`commands/combat.js`**
   - Modification de `createCombatEmbed()` pour afficher les tours du joueur

## ✅ Tests de Validation

- ✅ Syntaxe JavaScript validée
- ✅ Compteurs de tours séparés fonctionnels
- ✅ Affichage mis à jour dans l'interface
- ✅ Vérifications de limite de tours correctes

## 📝 Notes Importantes

- Le champ `combat.turn` est conservé pour la compatibilité (compte toujours les tours globaux)
- La limite de tours s'applique maintenant **uniquement au joueur principal** (`playerTurns`)
- En PvE, le monstre peut également jouer 10 tours avant la fin du combat
- L'ancien système comptait les tours globalement, le nouveau compte par joueur

---

**Date de mise à jour :** Janvier 2025  
**Version :** 2.0 - Système de tours individuels
