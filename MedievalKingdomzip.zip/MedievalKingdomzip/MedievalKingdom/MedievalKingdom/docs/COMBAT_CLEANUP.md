# Système de Nettoyage Automatique des Combats

## Vue d'ensemble

Le système de nettoyage automatique des combats a été implémenté pour gérer automatiquement les combats expirés et éviter l'accumulation de combats inactifs en mémoire.

## Fonctionnalités

### 1. Expiration Automatique
- **Durée d'expiration** : 5 minutes (300 000 ms)
- Chaque combat créé reçoit un timestamp `expiresAt`
- S'applique aux combats PvE (contre monstres) et PvP (duels)

### 2. Nettoyage Périodique
- **Intervalle** : Toutes les 30 secondes
- Parcourt tous les combats actifs
- Supprime automatiquement les combats expirés
- Gère correctement les combats PvP (supprime les deux entrées)

### 3. Vérification en Temps Réel
- Lors de chaque interaction de combat, le système vérifie si le combat a expiré
- Si expiré, le combat est immédiatement supprimé
- L'utilisateur reçoit un message clair indiquant que le combat a expiré

## Implémentation Technique

### Fichiers Modifiés

#### `commands/combat.js`
- Ajout de la constante `COMBAT_EXPIRATION_TIME` (5 minutes)
- Fonction `cleanupExpiredCombats()` : nettoie les combats expirés
- Fonction `getActiveCombatsStats()` : statistiques des combats actifs
- Intervalle automatique lancé au chargement du module
- Ajout du timestamp `expiresAt` lors de la création d'un combat PvE

#### `events/interactionCreate.js`
- Import de `COMBAT_EXPIRATION_TIME`
- Ajout du timestamp `expiresAt` lors de la création d'un combat PvP
- Vérification de l'expiration dans `handleCombatButtons()`
- Suppression automatique des combats expirés détectés
- Messages d'erreur améliorés pour informer l'utilisateur

## Avantages

1. **Gestion Automatique** : Plus besoin de gérer manuellement les timeouts
2. **Économie de Mémoire** : Les combats inactifs sont automatiquement supprimés
3. **Expérience Utilisateur** : Messages clairs quand un combat expire
4. **Prévention des Bugs** : Évite les combats "fantômes" qui restent en mémoire
5. **Cohérence** : Même logique pour PvE et PvP

## Logs

Le système génère des logs pour le suivi :
- `🧹 Combat expiré supprimé pour l'utilisateur {userId}` : Combat individuel supprimé
- `✅ {count} combat(s) expiré(s) nettoyé(s)` : Résumé du nettoyage périodique

## Statistiques

La fonction `getActiveCombatsStats()` permet d'obtenir :
- Nombre total de combats actifs
- Nombre de combats PvE
- Nombre de combats PvP
- Nombre de combats expirés (mais pas encore nettoyés)
- Nombre d'entrées dans la Map

## Configuration

Pour modifier la durée d'expiration, changez la constante dans `commands/combat.js` :

```javascript
// Durée d'expiration des combats (5 minutes en millisecondes)
const COMBAT_EXPIRATION_TIME = 5 * 60 * 1000;
```

Pour modifier l'intervalle de nettoyage :

```javascript
// Lancer le nettoyage automatique toutes les 30 secondes
setInterval(cleanupExpiredCombats, 30000);
```

## Messages Utilisateur

### Combat Non Trouvé
```
❌ Combat non trouvé ou expiré.

Le combat a été automatiquement supprimé.
```

### Combat Expiré
```
⏰ Ce combat a expiré et a été automatiquement supprimé.

Vous pouvez démarrer un nouveau combat.
```

## Notes Techniques

- Les combats PvP ont deux entrées dans la Map (une par joueur)
- Le nettoyage gère correctement la suppression des deux entrées
- Le système est non-bloquant et n'affecte pas les performances
- Compatible avec le système de timeout existant (qui a été simplifié)